import java.sql.*;
import java.util.Scanner;

public class ExpenseTracker {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/expense_db";
    private static final String DB_USER = "root";        // Change if needed
    private static final String DB_PASSWORD = "Robert"; // Change to your password

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            do {
                printMenu();
                System.out.print("Enter choice: ");
                choice = getIntInput();

                switch (choice) {
                    case 1 -> addExpense(conn);
                    case 2 -> viewExpenses(conn);
                    case 3 -> viewTotal(conn);
                    case 4 -> deleteExpense(conn);
                    case 5 -> System.out.println("Exiting... Goodbye!");
                    default -> System.out.println("Invalid choice. Try again.");
                }

                System.out.println();
            } while (choice != 5);
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Database connection failed.");
        }
    }

    private static void printMenu() {
        System.out.println("=== Expense Tracker (MySQL) ===");
        System.out.println("1. Add Expense");
        System.out.println("2. View All Expenses");
        System.out.println("3. View Total Expense");
        System.out.println("4. Delete Expense");
        System.out.println("5. Exit");
    }

    private static void addExpense(Connection conn) throws SQLException {
        System.out.print("Enter description: ");
        String description = scanner.nextLine();
        System.out.print("Enter amount (in ₹): ");
        double amount = getDoubleInput();

        String sql = "INSERT INTO expenses (description, amount) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, description);
            stmt.setDouble(2, amount);
            stmt.executeUpdate();
            System.out.println("Expense added successfully!");
        }
    }

    private static void viewExpenses(Connection conn) throws SQLException {
        String sql = "SELECT * FROM expenses";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            boolean hasResults = false;
            while (rs.next()) {
                hasResults = true;
                int id = rs.getInt("id");
                String desc = rs.getString("description");
                double amt = rs.getDouble("amount");
                System.out.printf("ID: %d | Description: %s | Amount: ₹%.2f%n", id, desc, amt);
            }
            if (!hasResults) {
                System.out.println("No expenses found.");
            }
        }
    }

    private static void viewTotal(Connection conn) throws SQLException {
        String sql = "SELECT SUM(amount) AS total FROM expenses";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                double total = rs.getDouble("total");
                System.out.printf("Total Expenses: ₹%.2f%n", total);
            }
        }
    }

    private static void deleteExpense(Connection conn) throws SQLException {
        System.out.print("Enter Expense ID to delete: ");
        int id = getIntInput();

        String sql = "DELETE FROM expenses WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Expense deleted successfully.");
            } else {
                System.out.println("Expense ID not found.");
            }
        }
    }

    private static int getIntInput() {
        while (!scanner.hasNextInt()) {
            System.out.print("Please enter a valid number: ");
            scanner.next(); // clear invalid input
        }
        int num = scanner.nextInt();
        scanner.nextLine(); // consume newline
        return num;
    }

    private static double getDoubleInput() {
        while (!scanner.hasNextDouble()) {
            System.out.print("Please enter a valid amount: ");
            scanner.next(); // clear invalid input
        }
        double num = scanner.nextDouble();
        scanner.nextLine(); // consume newline
        return num;
    }
}
